# RetailPro — Pre-entrega 5: Consultas con JOINs

## Entregable principal
`m5_consultas_joins.sql`

Incluye las cuatro consultas solicitadas:
1. Vista enriquecida con `INNER JOIN`.
2. Clientes sin ventas con `LEFT JOIN` y `WHERE ... IS NULL`.
3. Productos sin ventas con `LEFT JOIN` y `WHERE ... IS NULL`.
4. Consolidado por canal con dos `SELECT`, literales, `UNION ALL` y `GROUP BY`.

## Esquema de referencia
También se incluye `m3_esquema_retailpro.sql`, con tablas y datos de ejemplo para poder ejecutar las consultas en PostgreSQL. Si ya tenés el esquema original de M3, conservá tu modelo y verificá que los nombres de columnas coincidan. No subas un esquema de referencia como si fuera tu modelo original sin revisarlo.

## Cómo probarlo
1. Abrí pgAdmin o DBeaver y conectate a PostgreSQL.
2. Ejecutá `m3_esquema_retailpro.sql` en una base de prueba. Si usás `Ventas_Tech_DB`, seleccioná esa base antes de correr el script.
3. Ejecutá cada bloque de `m5_consultas_joins.sql` por separado.
4. Revisá que los resultados coincidan con los comentarios de hallazgo. Los importes de los comentarios corresponden únicamente a los datos de ejemplo incluidos.
5. Si ejecutás sobre tu base M3 real, actualizá los comentarios de hallazgo con los conteos e importes reales.

## Subida a GitHub
Subí `m5_consultas_joins.sql` en la misma carpeta que los archivos M3/M4 dentro del repositorio público. El archivo M3 incluido es solo una referencia de prueba; si tu repositorio ya tiene un esquema propio, no lo reemplaces automáticamente. Hacé commit/push y verificá que el archivo se vea desde GitHub sin iniciar sesión.
