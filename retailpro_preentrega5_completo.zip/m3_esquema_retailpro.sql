/*
Proyecto: RetailPro
Archivo de referencia: m3_esquema_retailpro.sql
Motor: PostgreSQL
Base sugerida: Ventas_Tech_DB

Este esquema de referencia es autocontenido y permite probar la pre-entrega 5.
Si ya tenés un esquema M3 propio, compará las tablas/columnas antes de ejecutar
este archivo: no reemplaces tu modelo anterior sin revisar las diferencias.
*/

CREATE TABLE IF NOT EXISTS clientes (
    id_cliente       INTEGER PRIMARY KEY,
    nombre           VARCHAR(100) NOT NULL,
    email            VARCHAR(150) UNIQUE NOT NULL,
    fecha_registro   DATE NOT NULL,
    segmento         VARCHAR(40) NOT NULL,
    region            VARCHAR(60) NOT NULL
);

CREATE TABLE IF NOT EXISTS productos (
    id_producto      INTEGER PRIMARY KEY,
    nombre_producto  VARCHAR(120) NOT NULL,
    categoria        VARCHAR(60) NOT NULL,
    precio           NUMERIC(12,2) NOT NULL CHECK (precio >= 0)
);

CREATE TABLE IF NOT EXISTS ventas (
    id_venta         INTEGER PRIMARY KEY,
    id_cliente       INTEGER NOT NULL REFERENCES clientes(id_cliente),
    id_producto      INTEGER NOT NULL REFERENCES productos(id_producto),
    cantidad         INTEGER NOT NULL CHECK (cantidad > 0),
    precio_unitario  NUMERIC(12,2) NOT NULL CHECK (precio_unitario >= 0),
    fecha_venta      DATE NOT NULL,
    origen_venta     VARCHAR(20) NOT NULL CHECK (origen_venta IN ('Online', 'Presencial'))
);

-- Datos de ejemplo para validar las consultas.
-- ON CONFLICT permite volver a ejecutar el script sin duplicar estos IDs.
INSERT INTO clientes (id_cliente, nombre, email, fecha_registro, segmento, region) VALUES
(1, 'Ana López', 'ana.lopez@example.com', '2025-01-12', 'Minorista', 'Centro'),
(2, 'Bruno Díaz', 'bruno.diaz@example.com', '2025-02-03', 'Mayorista', 'Norte'),
(3, 'Carla Ruiz', 'carla.ruiz@example.com', '2025-03-18', 'Minorista', 'Sur'),
(4, 'Diego Pérez', 'diego.perez@example.com', '2025-05-22', 'Empresa', 'Centro'),
(5, 'Eva Gómez', 'eva.gomez@example.com', '2025-06-09', 'Minorista', 'Oeste')
ON CONFLICT (id_cliente) DO NOTHING;

INSERT INTO productos (id_producto, nombre_producto, categoria, precio) VALUES
(101, 'Notebook Pro 14', 'Computación', 850000.00),
(102, 'Mouse inalámbrico', 'Accesorios', 18000.00),
(103, 'Teclado mecánico', 'Accesorios', 42000.00),
(104, 'Monitor 27 pulgadas', 'Monitores', 230000.00),
(105, 'Auriculares USB', 'Audio', 35000.00)
ON CONFLICT (id_producto) DO NOTHING;

INSERT INTO ventas (id_venta, id_cliente, id_producto, cantidad, precio_unitario, fecha_venta, origen_venta) VALUES
(1001, 1, 101, 1, 850000.00, '2025-01-20', 'Online'),
(1002, 2, 102, 2, 18000.00, '2025-02-14', 'Presencial'),
(1003, 1, 103, 1, 42000.00, '2025-03-02', 'Online'),
(1004, 3, 104, 1, 230000.00, '2025-04-11', 'Presencial'),
(1005, 4, 102, 3, 18000.00, '2025-05-07', 'Online'),
(1006, 2, 101, 1, 850000.00, '2025-06-19', 'Presencial')
ON CONFLICT (id_venta) DO NOTHING;
